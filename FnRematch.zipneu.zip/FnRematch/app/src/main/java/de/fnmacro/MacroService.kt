package de.fnmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.random.Random

class MacroService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MacroService? = null

        /** Summe der Farbabweichung (R+G+B), ab der eine Farbe noch als "gleich" gilt. */
        private const val TOLERANCE = 60

        /** Pause zwischen zwei Bildschirmprüfungen. */
        private const val POLL_MS = 1200L

        /** So viele Treffer hintereinander nötig, damit kurzes Aufblitzen nicht auslöst. */
        private const val HITS_NEEDED = 2

        /** Was beim Aufnehmen angetippt wird. */
        private const val KIND_ROUND = 0 // "Nächste Runde"-Button
        private const val KIND_STEP = 1 // weiterer Button
        private const val KIND_MOVE = 2 // Mitte des Bewegungs-Sticks
        private const val KIND_JUMP = 3 // Sprung-Button
    }

    private val ui = Handler(Looper.getMainLooper())
    private val shotExecutor = Executors.newSingleThreadExecutor()

    private lateinit var wm: WindowManager
    private lateinit var store: StepStore

    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var statusView: TextView? = null
    private var controlsBox: LinearLayout? = null
    private var stopButton: Button? = null
    private var overlay: View? = null

    @Volatile
    private var running = false
    private var worker: Thread? = null

    // ---------------------------------------------------------------- Lebenszyklus

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = StepStore(this)
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // wird nicht gebraucht, der Dienst arbeitet nur mit Screenshots und Gesten
    }

    override fun onInterrupt() {
        // Android ruft das z. B. bei Systemdialogen auf. Das Makro soll dabei weiterlaufen.
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopMacro()
        ui.post {
            overlay?.let { try { wm.removeView(it) } catch (e: Exception) { } }
            overlay = null
            panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
            panel = null
        }
        instance = null
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- Panel

    fun showPanel() {
        ui.post {
            val existing = panel
            if (existing != null) {
                existing.visibility = View.VISIBLE
                refreshStatus()
                return@post
            }

            val dp = resources.displayMetrics.density
            fun px(v: Int) = (v * dp).toInt()

            val status = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 13f
                setPadding(0, 0, 0, px(6))
            }

            fun btn(label: String, action: () -> Unit) = Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 13f
                setOnClickListener { action() }
            }

            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(btn("▶ Start") { startMacro() })
                addView(btn("+ Nächste Runde (Button)") { beginCalibration(KIND_ROUND) })
                addView(btn("+ Weiterer Button") { beginCalibration(KIND_STEP) })
                addView(btn("+ Bewegungs-Stick (Anti-AFK)") { beginCalibration(KIND_MOVE) })
                addView(btn("+ Sprung-Button (Anti-AFK)") { beginCalibration(KIND_JUMP) })
                addView(btn("Schritte löschen") { clearSteps() })
                addView(btn("Panel ausblenden") { panel?.visibility = View.GONE })
            }

            val stop = btn("■ Stop") { stopMacro() }.apply { visibility = View.GONE }

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(Color.argb(210, 20, 20, 20))
                setPadding(px(8), px(8), px(8), px(8))
                addView(status)
                addView(controls)
                addView(stop)
            }

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = px(8)
                y = px(8)
            }

            // Panel verschieben: am Statustext ziehen
            var startX = 0f
            var startY = 0f
            var origX = 0
            var origY = 0
            status.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = e.rawX
                        startY = e.rawY
                        origX = lp.x
                        origY = lp.y
                    }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = origX + (e.rawX - startX).toInt()
                        lp.y = origY + (e.rawY - startY).toInt()
                        wm.updateViewLayout(root, lp)
                    }
                }
                true
            }

            wm.addView(root, lp)
            panel = root
            panelParams = lp
            statusView = status
            controlsBox = controls
            stopButton = stop
            refreshStatus()
        }
    }

    private fun refreshStatus() {
        val steps = store.load()
        val afk = if (store.loadPoint("move") != null || store.loadPoint("jump") != null) "an" else "aus"
        statusView?.text = if (steps.isEmpty()) {
            "Keine Schritte. Rundenende-Bildschirm zeigen, dann \"+ Nächste Runde\"."
        } else {
            "Ablauf: " + steps.joinToString(" → ") { it.name } +
                "\nAnti-AFK: $afk\n(hier ziehen = Panel verschieben)"
        }
    }

    private fun setStatus(text: String) {
        ui.post { statusView?.text = text }
    }

    private fun setRunningUi(on: Boolean) {
        ui.post {
            controlsBox?.visibility = if (on) View.GONE else View.VISIBLE
            stopButton?.visibility = if (on) View.VISIBLE else View.GONE
            if (!on) refreshStatus()
        }
    }

    private fun toast(msg: String) {
        ui.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun alert(msg: String) {
        toast(msg)
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            // Vibration ist nur ein Extra
        }
    }

    private fun clearSteps() {
        store.save(emptyList())
        store.clearPoints()
        refreshStatus()
    }

    // ---------------------------------------------------------------- Aufnahme eines Schritts

    private fun beginCalibration(kind: Int) {
        if (running) return
        panel?.visibility = View.GONE
        toast("Screenshot in 5 Sekunden. Bring das Spiel jetzt auf den richtigen Bildschirm.")
        ui.postDelayed({
            Thread {
                val bmp = grab()
                ui.post {
                    if (bmp == null) {
                        toast("Screenshot fehlgeschlagen. Nochmal versuchen.")
                        panel?.visibility = View.VISIBLE
                    } else {
                        showCalibrationOverlay(bmp, kind)
                    }
                }
            }.start()
        }, 5000)
    }

    private fun showCalibrationOverlay(bmp: Bitmap, kind: Int) {
        val dp = resources.displayMetrics.density

        val image = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
        }

        val hint = TextView(this).apply {
            text = when (kind) {
                KIND_MOVE -> "Tippe auf die Mitte des Bewegungs-Sticks."
                KIND_JUMP -> "Tippe auf den Sprung-Button."
                else -> "Tippe auf eine einfarbige Stelle des Buttons (nicht auf den Text)."
            }
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(190, 0, 0, 0))
            textSize = 18f
            val p = (12 * dp).toInt()
            setPadding(p, p, p, p)
        }

        val cancel = Button(this).apply {
            text = "Abbrechen"
            isAllCaps = false
            setOnClickListener { closeOverlay() }
        }

        val frame = FrameLayout(this).apply {
            addView(
                image,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                )
            )
            addView(
                hint,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.CENTER_HORIZONTAL,
                )
            )
            addView(
                cancel,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
                )
            )
        }

        image.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP && v.width > 0 && v.height > 0) {
                val xf = (e.x / v.width).coerceIn(0f, 1f)
                val yf = (e.y / v.height).coerceIn(0f, 1f)
                if (kind == KIND_MOVE || kind == KIND_JUMP) {
                    store.savePoint(if (kind == KIND_MOVE) "move" else "jump", xf, yf)
                    closeOverlay()
                    toast("Gespeichert")
                } else {
                    val color = sample(bmp, xf, yf)
                    val steps = store.load()
                    val name = if (kind == KIND_ROUND) "Nächste Runde" else "Schritt ${steps.size + 1}"
                    // "Nächste Runde" darf lange dauern (30 Min), weitere Buttons 3 Min
                    steps.add(Step(name, xf, yf, color, if (kind == KIND_ROUND) 1800 else 180))
                    store.save(steps)
                    closeOverlay()
                    toast("Gespeichert: $name")
                }
            }
            true
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE,
        ).apply {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        wm.addView(frame, lp)
        overlay = frame
    }

    private fun closeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // schon entfernt
            }
        }
        overlay = null
        panel?.visibility = View.VISIBLE
        refreshStatus()
    }

    // ---------------------------------------------------------------- Makro-Schleife

    private fun startMacro() {
        if (running) return
        val steps = store.load()
        if (steps.isEmpty()) {
            toast("Erst den \"Nächste Runde\"-Button aufnehmen.")
            return
        }
        running = true
        setRunningUi(true)
        worker = Thread { runLoop(steps) }.apply {
            isDaemon = true
            start()
        }
    }

    private fun stopMacro() {
        running = false
        worker?.interrupt()
        setRunningUi(false)
    }

    private fun runLoop(steps: List<Step>) {
        val move = store.loadPoint("move")
        val jump = store.loadPoint("jump")
        var round = 1
        var index = 0
        var nextAfk = System.currentTimeMillis() + Random.nextLong(15_000, 35_000)
        try {
            while (running) {
                val step = steps[index]
                setStatus("Runde $round · warte auf: ${step.name}")

                // "Nächste Runde" darf bis zu 6 Stunden dauern, andere Buttons laut Aufnahme
                val timeoutSec = if (step.name == "Nächste Runde") 6 * 3600 else step.timeoutSec
                val deadline = System.currentTimeMillis() + timeoutSec * 1000L
                var hits = 0
                var found = false

                while (running && System.currentTimeMillis() < deadline) {
                    val bmp = grab()
                    if (bmp != null) {
                        val current = sample(bmp, step.x, step.y)
                        hits = if (isClose(current, step.color)) hits + 1 else 0
                        if (hits >= HITS_NEEDED) {
                            pause(Random.nextLong(300, 800))
                            if (running) tap(step.x, step.y, bmp.width, bmp.height)
                            found = true
                        } else if ((move != null || jump != null) &&
                            System.currentTimeMillis() >= nextAfk
                        ) {
                            // Anti-AFK: während des Wartens ab und zu laufen und springen
                            antiAfk(bmp.width, bmp.height, move, jump)
                            nextAfk = System.currentTimeMillis() + Random.nextLong(15_000, 35_000)
                        }
                        bmp.recycle()
                        if (found) break
                    }
                    pause(POLL_MS + Random.nextLong(0, 400))
                }

                if (!running) break
                if (!found) {
                    alert("Zeitüberschreitung bei: ${step.name}. Makro gestoppt.")
                    break
                }

                // Warten, bis der Button weg ist. Sonst würde er sofort nochmal getippt.
                waitUntilGone(step)

                index++
                if (index >= steps.size) {
                    index = 0
                    round++
                }
                pause(Random.nextLong(1500, 2500))
            }
        } finally {
            running = false
            setRunningUi(false)
        }
    }

    /** Wartet bis zu 30 Sekunden, bis die Farbe des Schritts nicht mehr am Punkt zu sehen ist. */
    private fun waitUntilGone(step: Step) {
        val end = System.currentTimeMillis() + 30_000
        while (running && System.currentTimeMillis() < end) {
            pause(1000)
            val bmp = grab() ?: continue
            val still = isClose(sample(bmp, step.x, step.y), step.color)
            bmp.recycle()
            if (!still) return
        }
    }

    /** Wischt den Stick in eine zufällige Richtung und springt danach (falls aufgenommen). */
    private fun antiAfk(width: Int, height: Int, move: Pair<Float, Float>?, jump: Pair<Float, Float>?) {
        if (move != null) {
            val angle = Random.nextDouble(0.0, 2 * Math.PI)
            val dist = minOf(width, height) * 0.07f
            val sx = move.first * width
            val sy = move.second * height
            val ex = sx + (Math.cos(angle) * dist).toFloat()
            val ey = sy + (Math.sin(angle) * dist).toFloat()
            val path = Path().apply {
                moveTo(sx, sy)
                lineTo(ex, ey)
            }
            dispatch(path, Random.nextLong(600, 1500))
        }
        if (jump != null && running) {
            pause(Random.nextLong(200, 600))
            tap(jump.first, jump.second, width, height)
        }
    }

    private fun pause(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            running = false
        }
    }

    // ---------------------------------------------------------------- Screenshot, Farbe, Tippen

    /** Macht einen Screenshot und liefert ihn als normales Bitmap (oder null bei Fehler). */
    private fun grab(): Bitmap? {
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            shotExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        result = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        screenshot.hardwareBuffer.close()
                    } catch (e: Exception) {
                        result = null
                    }
                    latch.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    latch.countDown()
                }
            },
        )
        latch.await(3, TimeUnit.SECONDS)
        return result
    }

    /** Mittelwert der Farbe in einem kleinen Quadrat um den Punkt (gegen Bildrauschen). */
    private fun sample(bmp: Bitmap, xf: Float, yf: Float): Int {
        val cx = (xf * bmp.width).toInt().coerceIn(0, bmp.width - 1)
        val cy = (yf * bmp.height).toInt().coerceIn(0, bmp.height - 1)
        var r = 0
        var g = 0
        var b = 0
        var n = 0
        for (y in (cy - 3)..(cy + 3)) {
            for (x in (cx - 3)..(cx + 3)) {
                if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) continue
                val p = bmp.getPixel(x, y)
                r += Color.red(p)
                g += Color.green(p)
                b += Color.blue(p)
                n++
            }
        }
        if (n == 0) return Color.BLACK
        return Color.rgb(r / n, g / n, b / n)
    }

    private fun isClose(a: Int, b: Int): Boolean {
        val diff = abs(Color.red(a) - Color.red(b)) +
            abs(Color.green(a) - Color.green(b)) +
            abs(Color.blue(a) - Color.blue(b))
        return diff <= TOLERANCE
    }

    private fun tap(xf: Float, yf: Float, width: Int, height: Int): Boolean {
        val path = Path().apply { moveTo(xf * width, yf * height) }
        return dispatch(path, 70)
    }

    /** Führt eine Geste (Tippen oder Wischen) aus und wartet, bis sie fertig ist. */
    private fun dispatch(path: Path, durationMs: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()

        val latch = CountDownLatch(1)
        var ok = false
        dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true
                    latch.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    latch.countDown()
                }
            },
            null,
        )
        latch.await(2, TimeUnit.SECONDS)
        return ok
    }
}

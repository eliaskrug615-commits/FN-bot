package de.fnmacro

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(s: String, size: Float = 15f) = TextView(this).apply {
            text = s
            textSize = size
            setPadding(0, 0, 0, pad / 2)
        }

        fun button(s: String, action: () -> Unit) = Button(this).apply {
            text = s
            isAllCaps = false
            setOnClickListener { action() }
        }

        col.addView(label("Fortnite Rematch", 24f))
        col.addView(
            label(
                "Startet nach jeder Runde automatisch die nächste. Die App erkennt das " +
                    "Rundenende an einer Farbe auf dem Bildschirm und tippt dann den Button an."
            )
        )

        col.addView(label("1. Android 13+: Bei Apps außerhalb des Play Store zuerst in den App-Infos oben rechts \"Eingeschränkte Einstellungen zulassen\" wählen."))
        col.addView(button("App-Info öffnen") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        })

        col.addView(label("2. Bedienungshilfen öffnen und \"Fortnite Rematch\" einschalten."))
        col.addView(button("Bedienungshilfen öffnen") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        col.addView(label("3. Danach schwebt ein Panel über dem Bildschirm. Falls es weg ist:"))
        col.addView(button("Panel anzeigen") {
            val service = MacroService.instance
            if (service == null) {
                Toast.makeText(this, "Dienst ist noch nicht aktiv (Schritt 2).", Toast.LENGTH_LONG).show()
            } else {
                service.showPanel()
            }
        })

        col.addView(
            label(
                "4. Öffne Fortnite und nimm auf:\n" +
                    "   a) Rundenende mit dem \"Nächste Runde\"-Button sichtbar: Panel > \"+ Nächste Runde\"\n" +
                    "   b) Gegen AFK, in einer laufenden Runde: \"+ Bewegungs-Stick\" (Mitte des Sticks) und \"+ Sprung-Button\"\n" +
                    "   c) Falls danach noch ein Button kommt: \"+ Weiterer Button\"\n" +
                    "   Tippe beim Aufnehmen auf eine einfarbige Stelle des Buttons, nicht auf den Text.\n\n" +
                    "5. Panel > \"Start\". \"Stop\" beendet das Makro."
            )
        )

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
